import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import Card from './Card.jsx'
import CardList from './CardList.jsx'
import CardForm from './CardForm.jsx'
import './App.css'

function App() {

  return (
    <>
      <h1>Cards</h1>
      
      <CardList/>
      
    </>
  )
}

export default App

