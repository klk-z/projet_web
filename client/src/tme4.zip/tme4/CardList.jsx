import { useState } from 'react'
import Card from './Card.jsx'
import './App.css'
import CardForm from './CardForm.jsx'

const initialCards = [{symbol:"♥", affichage:"visible"}, {symbol:"♣", affichage:"visible"}, {symbol:"♦", affichage:"visible"}, {symbol:"♠", affichage:"visible"}]

function CardList() {
    
    const [cards, setCards] = useState(initialCards)

    function addCard(newCard){
        setCards([...cards,newCard])
    }

    return (
    <>
      <div className="cardlist">
        {cards.map((card, index) => <ul key={index}>
            <Card symbol={card.symbol} affichage={card.affichage} />
            </ul>)}
      </div>
      <CardForm onAdd={addCard}/>
    </>
    );
  }
  
  
  
  export default CardList