import { useState } from 'react'
import './App.css'

function Card(props) {
  const symbol = props.symbol;
  const [affichage, setAffichage] = useState(props.affichage);

  const setVisibility = () => {
    affichage === 'visible' ? setAffichage("hidden") : setAffichage("visible"); // Utilisez setAffichage pour modifier l'état
  };

  return (
    <div className="card" onClick={setVisibility}>
      {affichage === 'visible' ? symbol : '-'}
    </div>
  );
}



export default Card
