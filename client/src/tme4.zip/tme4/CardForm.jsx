import { useState } from 'react'
import Card from './Card.jsx'
import './App.css'

function CardForm({onAdd}) {
    
    function submitCard(e){
        e.preventDefault()
        const symbol = e.target.symbol.value
        const visibility = e.target.visibility.value
        console.log(symbol,visibility)
        return (onAdd({symbol: symbol, affichage: visibility}))

    }

    return (
    <div>
    <h2>Make a new card</h2>
      <form onSubmit={submitCard}>
        <label htmlFor="symbol">Symbol : </label><input type="text" name="symbol" id="symbol" /><br></br>
        <label htmlFor="visibility">Choose visibility : </label>
        <select name="visilbility" id="visibility">
            <option value="visible">visible</option>
            <option value="hidden">hidden</option>
        </select><br></br>
        <button type="submit" value="Submit" >Submit</button>
      </form>
    </div>
    );
  }
  
  
  
  export default CardForm